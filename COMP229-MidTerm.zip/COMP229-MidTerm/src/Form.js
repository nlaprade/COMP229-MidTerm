import React, { useState } from 'react';

const Form = (props) => {
  // Setting the constants for each form category
  // Setting their value to blank
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [quantity, setQuantity] = useState('');
  const [price, setPrice] = useState('');

  const handleCancel = () => {
    // This is the only way I can think of removing all data from the fields
    setName('');
    setDescription('');
    setCategory('');
    setQuantity('');
    setPrice('');
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = { 
      name, 
      description, 
      category, 
      quantity: parseInt(quantity, 10), 
      price: parseFloat(price) 
    };
    console.log('Form data submitted:', formData);
    props.onDataSubmit(formData);
    // Receiving data from parent 'props'
    // Passing formData constant to onDataSubmit
  };

  return (
    // Form that the App.js requests, each value is set to the constants inside the Form constant
    // Added a 'required' boolean to prevent the user from leaving any data empty
    // There are two buttons (submit/cancel)
    // The submit button submits using the handleSubmit function
    // The cancel button changes all the data values back to blank
    <form onSubmit={handleSubmit}>
    <div className="form-group custom-textarea">
        <label className='App-link'>Name</label>
        <input type="text" className="form-control" value={name} onChange={(e) => setName(e.target.value)} required/>
    </div>
    <div className="form-group custom-textarea">
        <label className='App-link'>Description</label>
        <input type="text" className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} required/>
    </div>
    <div className="form-group custom-textarea">
        <label className='App-link'>Category</label>
        <input type="text" className="form-control" value={category} onChange={(e) => setCategory(e.target.value)} required/>
    </div>
    <div className="form-group custom-textarea">
        <label className='App-link'>Quantity</label>
        <input type="number" className="form-control" value={quantity} onChange={(e) => setQuantity(e.target.value)} required/>
    </div>
    <div className="form-group custom-textarea">
        <label className='App-link'>Price</label>
        <input type="number" step="0.01" className="form-control" value={price} onChange={(e) => setPrice(e.target.value)} required/>
    </div>
    <button type="submit" className="btn btn-secondary btn-sm button-spacing">Submit</button>
    <button type="button" className="btn btn-white btn-sm btn-outline-dark" onClick={handleCancel}>Cancel</button>
</form>
  )
}

export default Form;
