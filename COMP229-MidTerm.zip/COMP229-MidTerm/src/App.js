import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

// Importing Form.js functions
import './App.css';
import Form from './Form';

// Functions inside of App function
function App() {
  const [submittedData, setSubmittedData] = useState([]);

  const handleDataSubmit = (data) => {
    setSubmittedData(prevData => prevData.concat(data));
  }

  const handleDelete = (indexToDelete) => {
    setSubmittedData(prevData => prevData.filter((_, index) => index !== indexToDelete));
  }

  return (
    <div className="App">
      <h1 className="App-link move-down">New Product</h1>
      <div className="form-container">
        <Form onDataSubmit={handleDataSubmit} />
      </div>
      <div className="data-container">
        <h2 className='App-link'>Submitted Data</h2>
        {submittedData.map((data, index) => (
          // I created this div element that holds the submitted data from the form
          // Added an x button to delete the div element
          <div key={index}>
            <button onClick={() => handleDelete(index)}>x</button>
            <p><strong>Name</strong> {data.name}</p>
            <p><strong>Description</strong> {data.description}</p>
            <p><strong>Category</strong> {data.category}</p>
            <p><strong>Quantity</strong> {data.quantity}</p>
            <p><strong>Price</strong> {data.price}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
